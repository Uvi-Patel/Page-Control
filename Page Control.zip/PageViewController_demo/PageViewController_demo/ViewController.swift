//
//  ViewController.swift
//  PageViewController_demo
//
//  Created by MAC on 14/06/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
 //var PageControl = UIPageControl()
    
    var pages = ["abc","aabb","icons8-move-100","together"]
    @IBOutlet weak var collectionVIEW: UICollectionView!
    // @IBOutlet weak var lbl: UILabel!
   
    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var PageControl: UIPageControl!
//
//    @IBAction func changePage(_ sender: UIPageControl) {
//        lbl.text = "Page \(sender.currentPage + 1)"
//
//           switch sender.currentPage {
//           case 0:
//               sender.backgroundColor = UIColor.black
//           case 1:
//               sender.backgroundColor = UIColor.gray
//           case 2:
//               sender.backgroundColor = UIColor.orange
//           case 3:
//                sender.backgroundColor = UIColor.systemPink
//           default:
//               sender.backgroundColor = UIColor.brown
//        }
//    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionVIEW.delegate = self
        collectionVIEW.dataSource = self
        collectionVIEW.isPagingEnabled = true
        
        // Do any additional setup after loading the view.

       // PageControl.frame = CGRect(x: 0, y:500, width: self.view.frame.size.width, height: 50)
        //PageControl.backgroundColor = UIColor.cyan
       // PageControl.hidesForSinglePage = true
        PageControl.numberOfPages = pages.count
       // PageControl.currentPage = 2

        PageControl.pageIndicatorTintColor = UIColor.yellow
       // PageControl.defersCurrentPageDisplay = false
        PageControl.transform = CGAffineTransform(scaleX: 2, y: 2)
        PageControl.currentPageIndicatorTintColor = UIColor.blue
        //self.view.addSubview(PageControl)
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        PageControl.currentPage = indexPath.row
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("indexpath \(indexPath)")
        print("row \(indexPath.row)")
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    
        return pages.count
    }
   
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! MyCustomVollectionViewCell
        //cell.cell_lbl.text = pages[indexPath.row]
        cell.imgVIEW.image = UIImage(named: pages[indexPath.row]) 
        return cell
    }
    
}

class MyCustomVollectionViewCell: UICollectionViewCell {
  
    @IBOutlet weak var imgVIEW: UIImageView!
    // @IBOutlet weak var imgVIEW: UIImageView!
    //@IBOutlet weak var imgVIEW: UIImageView!
}
